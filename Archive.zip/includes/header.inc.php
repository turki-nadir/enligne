<!DOCTYPE html>
<html lang="fr">
    <head>
        <meta charset="utf-8">
        <title>Mon blog</title>
        <meta name="description" content="Petit blog pour m'initier à PHP">
        <meta name="TURKI Nadhir" content="TURKI">
        <meta http-equiv="pragma" content="no-cache" />
        <meta http-equiv="cache-control" content="no-cache" />
        <!-- Le HTML5 shim, for IE6-8 support of HTML elements -->
        <!--[if lt IE 9]>
          <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
        <![endif]-->
        <link href="css/bootstrap.min.css" rel="stylesheet">
        <link href="css/main.css" rel="stylesheet">
    </head>
    <body>
        <div class="container">
            <div class="content">
                <div class="page-header well">
                    <h1><a href="index.php" style="text-decoration:none">Blog de TURKI Nadhir <small><strong>Bienvenue</strong></small></a></h1>
                </div>
                <div class="row">